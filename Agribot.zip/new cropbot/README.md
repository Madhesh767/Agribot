pip install -p requirements.txt


run 

python app.py